import { pool } from './conexion_db.js';

// CRUD COMPLETO PARA 

// GET /prestamos → Listar todos los 
export const getInvoice = async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT 
                t.id_transactions,
                t.amount_paid,
                i.invoice_number,
                c.name
            FROM "transaction" t 
            JOIN invoice i ON t.invoice_number =i.invoice_number 
            JOIN client c ON t.id_client  = c.id_client ;
        `);
        res.json(result.rows);
    } catch (error) {
        console.error('Error al obtener préstamos:', error.message);
        res.status(500).json({ error: 'Error al obtener préstamos' });
    }
};

// GET /invoice/:id → Obtener cliente por ID
// GET /invoice/:id → Obtener cliente por ID
export const getClientById = async (req, res) => {
    try {
        const { id } = req.params;
        console.log("ID recibido en getClientById:", id, typeof id); // <-- Para depurar
        
        // Validación adicional para asegurarnos de que sea un número
        const idNumerico = parseInt(id, 10);
        if (isNaN(idNumerico)) {
             console.error('ID no es un número válido:', id);
             return res.status(400).json({ error: 'ID inválido, debe ser un número' });
        }
        
        const result = await pool.query(`
            
             SELECT 
                t.id_transactions,
                t.amount_paid,
                i.invoice_number,
                c.name
            FROM "transaction" t 
            JOIN invoice i ON t.invoice_number =i.invoice_number 
            JOIN client c ON t.id_client  = c.id_client ;
            WHERE c.id_client = $1
        `, [idNumerico]); // Usar el ID numérico
        
        // ... resto del código ...
    } catch (error) {
        console.error('Error al obtener usuarios:', error.message);
        res.status(500).json({ error: 'Error al obtener préstamo' });
    }
};

// DELETE /prestamos/:id → Eliminar un préstamo
export const deleteClient = async (req, res) => {
    try {
        const { id } = req.params;
        
        const result = await pool.query('DELETE FROM client WHERE id_client = $1 RETURNING *', [id]);
        
        if (result.rowCount === 0) {
            return res.status(404).json({ error: 'Préstamo no encontrado' });
        }
        
        res.json({
            message: 'client eliminado exitosamente',
            prestamo: result.rows[0]
        });
        
    } catch (error) {
        console.error('Error al eliminar client:', error.message);
        res.status(500).json({ error: 'Error al eliminar client' });
    }
};
