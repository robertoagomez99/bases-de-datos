import express from 'express';
import cors from 'cors';
import { pool } from './conexion_db.js';
import { 
    getInvoice, 
    getClientById, 
    deleteClient,

} from './invoice.js';

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Ruta principal de prueba
app.get('/', (req, res) => {
    res.json({ 
        message: '🚀 sistema financieron está funcionando!',
        endpoints: {
            prestamos: {
                get_all: 'GET /invoice',
                get_by_id: 'GET /client/:id',
                delete: 'DELETE /client/:id'
            },
        }
    });
});

app.get('/invoice',  getInvoice,);
app.get('/client/:id', getClientById);;
app.delete('/client/:id', deleteClient);

;


app.listen(PORT, () => {
    console.log(`🚀 Servidor backend corriendo en http://localhost:${PORT}`);
    console.log(`📚 API disponible en http://localhost:${PORT}/`);
});